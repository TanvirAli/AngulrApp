(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/app.component.html":
/*!**************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/app.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-main-nav></app-main-nav>\n<app-homeslider></app-homeslider>\n<app-main></app-main>\n<app-footer></app-footer>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/footer/footer.component.html":
/*!************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/footer/footer.component.html ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p>Copyright &copy;\t2019</p>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/header/header.component.html":
/*!************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/header/header.component.html ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p>Header workds</p>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/homeslider/homeslider.component.html":
/*!********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/homeslider/homeslider.component.html ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row-main\" id=\"home\">  \r\n<ngx-slick-carousel class=\"carousel\" #slickModal=\"slick-carousel\" [config]=\"slideConfig\">  \r\n    <div ngxSlickItem *ngFor=\"let image of images\" class=\"slide\">  \r\n    <div class=\"slider-inner\"> \r\n        <img src=\"{{ image.img }}\" width=\"100%\">\r\n    </div>\r\n    </div>  \r\n</ngx-slick-carousel>  \r\n</div>\r\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/main-nav/main-nav.component.html":
/*!****************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/main-nav/main-nav.component.html ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<div class=\"fx_preloader\" style=\"display: none;\"> <mat-spinner value=\"100\"></mat-spinner></div>\n<mat-toolbar id=\"main-nav-row\" color=\"primary\" fxLayout=\"row center\" fxLayoutAlign=\"start center\">\n  <mat-toolbar class=\"inner-nav-row\"><a href=\"#\">\n    <img src=\"assets/angular.png\" style=\"height: 100px\"></a>\n      <mat-nav-list>\n      <a mat-list-item href=\"#home\">Home</a>\n      <a mat-list-item href=\"#about\">About</a>\n      <a mat-list-item href=\"#services\">Services</a>\n      <a mat-list-item href=\"#contact\">Contact</a>\n    </mat-nav-list>\n  </mat-toolbar>  \n</mat-toolbar>\n<mat-sidenav-container id=\"mob-nav\" class=\"sidenav-container\">\n  <mat-sidenav #drawer class=\"sidenav\" fixedInViewport >\n<!--       [attr.role]=\"(isHandset$ | async) ? 'dialog' : 'navigation'\"\n      [mode]=\"(isHandset$ | async) ? 'over' : 'side'\"\n      [opened]=\"(isHandset$ | async) === false\"> -->\n    <mat-toolbar>Menu</mat-toolbar>\n    <mat-nav-list>\n      <a mat-list-item href=\"#home\">Home</a>\n      <a mat-list-item href=\"#about\">About</a>\n      <a mat-list-item href=\"#services\">Services</a>\n      <a mat-list-item href=\"#contact\">Contact</a>    \n    </mat-nav-list>\n  </mat-sidenav>\n  <mat-sidenav-content>\n    <mat-toolbar color=\"primary\">\n      <button\n        type=\"button\"\n        aria-label=\"Toggle sidenav\"\n        mat-icon-button\n        (click)=\"drawer.toggle()\"\n        *ngIf=\"isHandset$ | async\">\n        <mat-icon id=\"menu_lable\" aria-label=\"Side nav toggle icon\">menu</mat-icon>\n      </button>\n      <span></span>\n    </mat-toolbar>\n    <!-- Add Content Here -->\n  </mat-sidenav-content>\n</mat-sidenav-container>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/main/about-us/about-us.component.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/main/about-us/about-us.component.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\" data-aos=\"fade-up\" data-aos-offset=\"500\" data-aos-easing=\"ease-in-sine\" id=\"about\" >\n    <div class=\"about text-center\">\n            <h2 class=\"site-title\">About Us</h2>\n            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n    </div>         \n</div>\n \n\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/main/contac-form/contac-form.component.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/main/contac-form/contac-form.component.html ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\" data-aos=\"fade-up\" data-aos-offset=\"500\" data-aos-easing=\"ease-in-sine\" id=\"contact\">\n    <div class=\"about contact text-center \">\n            <h2 class=\"site-title\">Contact Us</h2>\n            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text </p>\n    </div>        \n    <div class=\"contact-form col-sm-12\">\n    \t<div class=\"col-sm-2\"></div>\n    \t<form class=\"example-form col-sm-8\">\n\t\t  <div class=\"col-sm-6\">\n\t\t  \t<mat-form-field class=\"example-full-width\">\n\t\t    \t<input matInput placeholder=\"First Name\" value=\"\">\n\t\t  \t</mat-form-field>\t\n\t\t  </div>\n\t\t  <div class=\"col-sm-6\">\n\t\t  \t<mat-form-field class=\"example-full-width\">\n\t\t    \t<input matInput placeholder=\"Last Name\" value=\"\">\n\t\t  \t</mat-form-field>\t\n\t\t  </div>\n\t\t  <div class=\"col-sm-6\">\n\t\t  \t<mat-form-field class=\"example-full-width\">\n\t\t    \t<input matInput placeholder=\"Phone No\" value=\"\">\n\t\t  \t</mat-form-field>\t\n\t\t  </div>\n\t\t  <div class=\"col-sm-6\">\n\t\t  \t<mat-form-field class=\"example-full-width\">\n\t\t    \t<input matInput placeholder=\"Company\" value=\"\">\n\t\t  \t</mat-form-field>\t\n\t\t  </div>\n\t\t  <div class=\"col-sm-12\">\n\t\t  <mat-form-field class=\"example-full-width\">\n\t\t    <textarea matInput placeholder=\"Send a Message\"></textarea>\n\t\t  </mat-form-field>\n\t\t</div>\n\t\t  <div class=\"col-sm-12 text-center\">\n\t\t  <button mat-raised-button color=\"primary\">Submit</button>\n\t\t</div>\n\t\t</form>\n    <div class=\"col-sm-2\"></div>\n    </div> \n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/main/main.component.html":
/*!********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/main/main.component.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-about-us></app-about-us>\n<app-services></app-services>\n<app-our-skills></app-our-skills>\n<app-testimonilas></app-testimonilas>\n<app-contac-form></app-contac-form>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/main/our-skills/our-skills.component.html":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/main/our-skills/our-skills.component.html ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\" data-aos=\"fade-up\" data-aos-offset=\"800\" data-aos-easing=\"ease-in-sine\">\n    <div class=\"about skills text-center\">\n            <h2 class=\"site-title\">Our Skills</h2>\n            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\n    </div> \n    <div class=\"col-sm-2\"></div> \n    <div class=\"col-sm-8\">\n\t<mat-list>\n\t  <mat-list-item>Web Development \n\t  \t<mat-progress-bar mode=\"determinate\" value=\"95\"></mat-progress-bar>\n\t  </mat-list-item>\n\t  <mat-divider></mat-divider>\n\t  <mat-list-item>Graphics Designing\n\t  \t<mat-progress-bar mode=\"determinate\" value=\"80\"></mat-progress-bar>\n\t  </mat-list-item>\n\t  <mat-divider></mat-divider>\n\t  <mat-list-item>Social Media Marketing\n\t  \t<mat-progress-bar mode=\"determinate\" value=\"60\"></mat-progress-bar>\n\t  </mat-list-item>\n\t  <mat-divider></mat-divider>\n\t  \t<mat-list-item>Business Development\n\t  \t<mat-progress-bar mode=\"determinate\" value=\"75\"></mat-progress-bar>\n\t  </mat-list-item>\n\t</mat-list>    \t\n    </div>\n    <div class=\"col-sm-2\"></div>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/main/services/services-cards/services-cards.component.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/main/services/services-cards/services-cards.component.html ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container \" data-aos=\"fade-up\" data-aos-offset=\"500\" data-aos-easing=\"ease-in-sine\">\n\t<div class=\"row\">\n\t\t<div class=\"col-sm-4\" data-aos=\"fade-right\" data-aos-offset=\"600\" data-aos-easing=\"ease-in-sine\">\n\t\t\t<mat-card class=\"example-card\">\n\t\t\t  <img mat-card-image src=\"./assets/images/web-dev.jpg\" alt=\"Photo of a Web development\">\n\t\t\t  <mat-card-header>\n\t\t\t    <div mat-card-avatar class=\"example-header-image\"></div>\n\t\t\t    <mat-card-title>Web Development</mat-card-title>\n\t\t\t  </mat-card-header>\n\t\t\t  <mat-card-content>\n\t\t\t    <p>\n\t\t\t\tLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n\t\t\t    </p>\n\t\t\t  </mat-card-content>\n\t\t\t  <mat-card-actions>\n\t\t\t    <button mat-button color=\"primary\"><i class=\"material-icons\">favorite</i></button>\n\t\t\t    <button mat-button color=\"primary\"><i class=\"material-icons\">screen_share</i></button>\n\t\t\t    <button mat-button color=\"primary\" layout-align=\"end-start\"><i class=\"material-icons\">comment</i></button>\n\t\t\t  </mat-card-actions>\n\t\t\t</mat-card>\n\t\t</div><!--  col-sm-4 -->\t\n\t\t<div class=\"col-sm-4\" data-aos=\"fade-down\" data-aos-offset=\"600\" data-aos-easing=\"ease-in-sine\">\n\t\t\t<mat-card class=\"example-card\">\n\t\t\t  <img mat-card-image src=\"./assets/images/graphic-design.jpg\" alt=\"Photo of a Web development\">\n\t\t\t  <mat-card-header>\n\t\t\t    <div mat-card-avatar class=\"example-header-image\"></div>\n\t\t\t    <mat-card-title>Graphic Design</mat-card-title>\n\t\t\t  </mat-card-header>\n\t\t\t  <mat-card-content>\n\t\t\t    <p>\n\t\t\t\tLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n\t\t\t    </p>\n\t\t\t  </mat-card-content>\n\t\t\t  <mat-card-actions>\n\t\t\t    <button mat-button color=\"primary\"><i class=\"material-icons\">favorite</i></button>\n\t\t\t    <button mat-button color=\"primary\"><i class=\"material-icons\">screen_share</i></button>\n\t\t\t    <button mat-button color=\"primary\" layout-align=\"end-start\"><i class=\"material-icons\">comment</i></button>\n\t\t\t  </mat-card-actions>\n\t\t\t</mat-card>\n\t\t</div><!--  col-sm-4 -->\t\n\t\t<div class=\"col-sm-4\" data-aos=\"fade-left\" data-aos-offset=\"600\" data-aos-easing=\"ease-in-sine\">\n\t\t\t<mat-card class=\"example-card\">\n\t\t\t  <img mat-card-image src=\"./assets/images/social-media.jpg\" alt=\"Photo of a Web development\">\n\t\t\t  <mat-card-header>\n\t\t\t    <div mat-card-avatar class=\"example-header-image\"></div>\n\t\t\t    <mat-card-title>Social Media Marketing</mat-card-title>\n\t\t\t  </mat-card-header>\n\t\t\t  <mat-card-content>\n\t\t\t    <p>\n\t\t\t\tLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n\t\t\t    </p>\n\t\t\t  </mat-card-content>\n\t\t\t  <mat-card-actions>\n\t\t\t    <button mat-button color=\"primary\"><i class=\"material-icons\">favorite</i></button>\n\t\t\t    <button mat-button color=\"primary\"><i class=\"material-icons\">screen_share</i></button>\n\t\t\t    <button mat-button color=\"primary\" layout-align=\"end-start\"><i class=\"material-icons\">comment</i></button>\n\t\t\t  </mat-card-actions>\n\t\t\t</mat-card>\n\t\t</div><!--  col-sm-4 -->\t\n\t</div>\t\t\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/main/services/services.component.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/main/services/services.component.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\" data-aos=\"fade-up\" data-aos-offset=\"500\" data-aos-easing=\"ease-in-sine\" id=\"services\">\n    <div class=\"about services text-center color-white\">\n            <h2 class=\"site-title\">Our Services</h2>\n            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\n    </div>         \n</div>\n<app-services-cards></app-services-cards>/"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/main/testimonilas/testi-cards/testi-cards.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/main/testimonilas/testi-cards/testi-cards.component.html ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container animated\" animateOnScroll animationName=\"fadeIn\">\n\t<div class=\"test-main-row\">\n\t\t<div class=\"col-sm-4\">\n\t\t\t<mat-card class=\"example-card\">\n\t\t\t  <mat-card-header>\n\t\t\t    <div mat-card-avatar class=\"example-header-image\">\n\t\t\t    \t<img mat-card-image src=\"./assets/images/avatar-4.png\">\n\t\t\t    </div>\n\t\t\t    <mat-card-title>Amanda</mat-card-title>\n\t\t\t  </mat-card-header>\n\t\t\t  <mat-card-content>\n\t\t\t    <p>\n\t\t\t\tLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n\t\t\t    </p>\n\t\t\t  </mat-card-content>\n\t\t\t</mat-card>\n\t\t</div><!--  col-sm-4 -->\t\n\t\t<div class=\"col-sm-4\">\n\t\t\t<mat-card class=\"example-card\">\n\t\t\t  <mat-card-header>\n\t\t\t    <div mat-card-avatar class=\"example-header-image\">\n\t\t\t    \t<img mat-card-image src=\"./assets/images/avatar-1.png\">\n\t\t\t    </div>\n\t\t\t    <mat-card-title>John Doe</mat-card-title>\n\t\t\t  </mat-card-header>\n\t\t\t  <mat-card-content>\n\t\t\t    <p>\n\t\t\t\tLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n\t\t\t    </p>\n\t\t\t  </mat-card-content>\n\t\t\t</mat-card>\n\t\t</div><!--  col-sm-4 -->\n\t\t<div class=\"col-sm-4\">\n\t\t\t<mat-card class=\"example-card\">\n\t\t\t  <mat-card-header>\n\t\t\t    <div mat-card-avatar class=\"example-header-image\">\n\t\t\t    \t<img mat-card-image src=\"./assets/images/avatar-1.png\">\n\t\t\t    </div>\n\t\t\t    <mat-card-title>John</mat-card-title>\n\t\t\t  </mat-card-header>\n\t\t\t  <mat-card-content>\n\t\t\t    <p>\n\t\t\t\tLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n\t\t\t    </p>\n\t\t\t  </mat-card-content>\n\t\t\t</mat-card>\n\t\t</div><!--  col-sm-4 -->\t\t\n\n\t</div>\t\t\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/main/testimonilas/testimonilas.component.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/main/testimonilas/testimonilas.component.html ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\"  data-aos=\"fade-up\" data-aos-offset=\"500\" data-aos-easing=\"ease-in-sine\">\n    <div class=\"about services text-center color-white\">\n            <h2 class=\"site-title\">Our Testimonilas</h2>\n            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>\n    </div>\n    <app-testi-cards></app-testi-cards>         \n</div>\n"

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var routes = [];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var aos__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! aos */ "./node_modules/aos/dist/aos.js");
/* harmony import */ var aos__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(aos__WEBPACK_IMPORTED_MODULE_2__);



var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'NgApp';
    }
    /*  images = [
        { img: "../assets/images/1.jpg" },
        { img: "../assets/images/2.jpg" },
        { img: "../assets/images/3.jpg" },
        { img: "../assets/images/4.jpg" },
      ];
      
      slideConfig = {
        "slidesToShow": 1,
        "slidesToScroll":1,
        "dots": true,
        "infinite": true
      };*/
    AppComponent.prototype.ngOnInit = function () {
        aos__WEBPACK_IMPORTED_MODULE_2__["init"]({
            duration: 1200,
        });
    };
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/index.js!./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _header_header_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./header/header.component */ "./src/app/header/header.component.ts");
/* harmony import */ var _main_main_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./main/main.component */ "./src/app/main/main.component.ts");
/* harmony import */ var _footer_footer_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./footer/footer.component */ "./src/app/footer/footer.component.ts");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/esm5/button.es5.js");
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material/icon */ "./node_modules/@angular/material/esm5/icon.es5.js");
/* harmony import */ var _main_nav_main_nav_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./main-nav/main-nav.component */ "./src/app/main-nav/main-nav.component.ts");
/* harmony import */ var _angular_cdk_layout__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/cdk/layout */ "./node_modules/@angular/cdk/esm5/layout.es5.js");
/* harmony import */ var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/material/toolbar */ "./node_modules/@angular/material/esm5/toolbar.es5.js");
/* harmony import */ var _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/material/sidenav */ "./node_modules/@angular/material/esm5/sidenav.es5.js");
/* harmony import */ var _angular_material_list__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/material/list */ "./node_modules/@angular/material/esm5/list.es5.js");
/* harmony import */ var _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/material/progress-spinner */ "./node_modules/@angular/material/esm5/progress-spinner.es5.js");
/* harmony import */ var _homeslider_homeslider_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./homeslider/homeslider.component */ "./src/app/homeslider/homeslider.component.ts");
/* harmony import */ var ngx_slick_carousel__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ngx-slick-carousel */ "./node_modules/ngx-slick-carousel/fesm5/ngx-slick-carousel.js");
/* harmony import */ var _main_about_us_about_us_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./main/about-us/about-us.component */ "./src/app/main/about-us/about-us.component.ts");
/* harmony import */ var _main_services_services_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./main/services/services.component */ "./src/app/main/services/services.component.ts");
/* harmony import */ var _main_services_services_cards_services_cards_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./main/services/services-cards/services-cards.component */ "./src/app/main/services/services-cards/services-cards.component.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _main_our_skills_our_skills_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./main/our-skills/our-skills.component */ "./src/app/main/our-skills/our-skills.component.ts");
/* harmony import */ var ng2_animate_on_scroll__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ng2-animate-on-scroll */ "./node_modules/ng2-animate-on-scroll/dist/index.js");
/* harmony import */ var ng2_animate_on_scroll__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(ng2_animate_on_scroll__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @angular/material/progress-bar */ "./node_modules/@angular/material/esm5/progress-bar.es5.js");
/* harmony import */ var _main_testimonilas_testimonilas_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./main/testimonilas/testimonilas.component */ "./src/app/main/testimonilas/testimonilas.component.ts");
/* harmony import */ var _main_testimonilas_testi_cards_testi_cards_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./main/testimonilas/testi-cards/testi-cards.component */ "./src/app/main/testimonilas/testi-cards/testi-cards.component.ts");
/* harmony import */ var _main_contac_form_contac_form_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./main/contac-form/contac-form.component */ "./src/app/main/contac-form/contac-form.component.ts");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/esm5/input.es5.js");


















//import {MatSidenavModule} from '@angular/material/sidenav';














var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"],
                _header_header_component__WEBPACK_IMPORTED_MODULE_5__["HeaderComponent"],
                _main_main_component__WEBPACK_IMPORTED_MODULE_6__["MainComponent"],
                _footer_footer_component__WEBPACK_IMPORTED_MODULE_7__["FooterComponent"],
                _main_nav_main_nav_component__WEBPACK_IMPORTED_MODULE_13__["MainNavComponent"],
                _homeslider_homeslider_component__WEBPACK_IMPORTED_MODULE_19__["HomesliderComponent"],
                _main_about_us_about_us_component__WEBPACK_IMPORTED_MODULE_21__["AboutUsComponent"],
                _main_services_services_component__WEBPACK_IMPORTED_MODULE_22__["ServicesComponent"],
                _main_services_services_cards_services_cards_component__WEBPACK_IMPORTED_MODULE_23__["ServicesCardsComponent"],
                _main_our_skills_our_skills_component__WEBPACK_IMPORTED_MODULE_25__["OurSkillsComponent"],
                _main_testimonilas_testimonilas_component__WEBPACK_IMPORTED_MODULE_28__["TestimonilasComponent"],
                _main_testimonilas_testi_cards_testi_cards_component__WEBPACK_IMPORTED_MODULE_29__["TestiCardsComponent"],
                _main_contac_form_contac_form_component__WEBPACK_IMPORTED_MODULE_30__["ContacFormComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_3__["AppRoutingModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_8__["BrowserAnimationsModule"],
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_9__["FormsModule"],
                _angular_http__WEBPACK_IMPORTED_MODULE_10__["HttpModule"],
                _angular_material_button__WEBPACK_IMPORTED_MODULE_11__["MatButtonModule"],
                _angular_cdk_layout__WEBPACK_IMPORTED_MODULE_14__["LayoutModule"],
                _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_15__["MatToolbarModule"],
                _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_16__["MatSidenavModule"],
                _angular_material_icon__WEBPACK_IMPORTED_MODULE_12__["MatIconModule"],
                _angular_material_list__WEBPACK_IMPORTED_MODULE_17__["MatListModule"],
                _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_18__["MatProgressSpinnerModule"],
                //    MatIconModule,
                ngx_slick_carousel__WEBPACK_IMPORTED_MODULE_20__["SlickCarouselModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_24__["MatCardModule"],
                ng2_animate_on_scroll__WEBPACK_IMPORTED_MODULE_26__["AnimateOnScrollModule"].forRoot(),
                _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_27__["MatProgressBarModule"],
                _angular_material_input__WEBPACK_IMPORTED_MODULE_31__["MatInputModule"]
            ],
            providers: [],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/footer/footer.component.css":
/*!*********************************************!*\
  !*** ./src/app/footer/footer.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Zvb3Rlci9mb290ZXIuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/footer/footer.component.ts":
/*!********************************************!*\
  !*** ./src/app/footer/footer.component.ts ***!
  \********************************************/
/*! exports provided: FooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return FooterComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var FooterComponent = /** @class */ (function () {
    function FooterComponent() {
    }
    FooterComponent.prototype.ngOnInit = function () {
    };
    FooterComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-footer',
            template: __webpack_require__(/*! raw-loader!./footer.component.html */ "./node_modules/raw-loader/index.js!./src/app/footer/footer.component.html"),
            styles: [__webpack_require__(/*! ./footer.component.css */ "./src/app/footer/footer.component.css")]
        })
    ], FooterComponent);
    return FooterComponent;
}());



/***/ }),

/***/ "./src/app/header/header.component.css":
/*!*********************************************!*\
  !*** ./src/app/header/header.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2hlYWRlci9oZWFkZXIuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/header/header.component.ts":
/*!********************************************!*\
  !*** ./src/app/header/header.component.ts ***!
  \********************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var HeaderComponent = /** @class */ (function () {
    function HeaderComponent() {
    }
    HeaderComponent.prototype.ngOnInit = function () {
    };
    HeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-header',
            template: __webpack_require__(/*! raw-loader!./header.component.html */ "./node_modules/raw-loader/index.js!./src/app/header/header.component.html"),
            styles: [__webpack_require__(/*! ./header.component.css */ "./src/app/header/header.component.css")]
        })
    ], HeaderComponent);
    return HeaderComponent;
}());



/***/ }),

/***/ "./src/app/homeslider/homeslider.component.css":
/*!*****************************************************!*\
  !*** ./src/app/homeslider/homeslider.component.css ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2hvbWVzbGlkZXIvaG9tZXNsaWRlci5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/homeslider/homeslider.component.ts":
/*!****************************************************!*\
  !*** ./src/app/homeslider/homeslider.component.ts ***!
  \****************************************************/
/*! exports provided: HomesliderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomesliderComponent", function() { return HomesliderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var HomesliderComponent = /** @class */ (function () {
    function HomesliderComponent() {
        this.images = [
            { img: "../assets/images/1.jpg" },
            { img: "../assets/images/2.jpg" },
            { img: "../assets/images/3.jpg" },
            { img: "../assets/images/4.jpg" },
        ];
        this.slideConfig = {
            "slidesToShow": 1,
            "slidesToScroll": 1,
            "dots": true,
            "infinite": true
        };
    }
    HomesliderComponent.prototype.ngOnInit = function () {
    };
    HomesliderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-homeslider',
            template: __webpack_require__(/*! raw-loader!./homeslider.component.html */ "./node_modules/raw-loader/index.js!./src/app/homeslider/homeslider.component.html"),
            styles: [__webpack_require__(/*! ./homeslider.component.css */ "./src/app/homeslider/homeslider.component.css")]
        })
    ], HomesliderComponent);
    return HomesliderComponent;
}());



/***/ }),

/***/ "./src/app/main-nav/main-nav.component.css":
/*!*************************************************!*\
  !*** ./src/app/main-nav/main-nav.component.css ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".sidenav-container {\n  height: 100%;\n}\n\n.sidenav {\n  width: 200px;\n}\n\n.sidenav .mat-toolbar {\n  background: inherit;\n}\n\n.mat-toolbar.mat-primary {\n  position: -webkit-sticky;\n  position: sticky;\n  top: 0;\n  z-index: 1;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWFpbi1uYXYvbWFpbi1uYXYuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQVk7QUFDZDs7QUFFQTtFQUNFLFlBQVk7QUFDZDs7QUFFQTtFQUNFLG1CQUFtQjtBQUNyQjs7QUFFQTtFQUNFLHdCQUFnQjtFQUFoQixnQkFBZ0I7RUFDaEIsTUFBTTtFQUNOLFVBQVU7QUFDWiIsImZpbGUiOiJzcmMvYXBwL21haW4tbmF2L21haW4tbmF2LmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc2lkZW5hdi1jb250YWluZXIge1xuICBoZWlnaHQ6IDEwMCU7XG59XG5cbi5zaWRlbmF2IHtcbiAgd2lkdGg6IDIwMHB4O1xufVxuXG4uc2lkZW5hdiAubWF0LXRvb2xiYXIge1xuICBiYWNrZ3JvdW5kOiBpbmhlcml0O1xufVxuXG4ubWF0LXRvb2xiYXIubWF0LXByaW1hcnkge1xuICBwb3NpdGlvbjogc3RpY2t5O1xuICB0b3A6IDA7XG4gIHotaW5kZXg6IDE7XG59XG4iXX0= */"

/***/ }),

/***/ "./src/app/main-nav/main-nav.component.ts":
/*!************************************************!*\
  !*** ./src/app/main-nav/main-nav.component.ts ***!
  \************************************************/
/*! exports provided: MainNavComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainNavComponent", function() { return MainNavComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_cdk_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/cdk/layout */ "./node_modules/@angular/cdk/esm5/layout.es5.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");




var MainNavComponent = /** @class */ (function () {
    function MainNavComponent(breakpointObserver) {
        this.breakpointObserver = breakpointObserver;
        this.isHandset$ = this.breakpointObserver.observe(_angular_cdk_layout__WEBPACK_IMPORTED_MODULE_2__["Breakpoints"].Handset)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (result) { return result.matches; }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["share"])());
    }
    MainNavComponent.ctorParameters = function () { return [
        { type: _angular_cdk_layout__WEBPACK_IMPORTED_MODULE_2__["BreakpointObserver"] }
    ]; };
    MainNavComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-main-nav',
            template: __webpack_require__(/*! raw-loader!./main-nav.component.html */ "./node_modules/raw-loader/index.js!./src/app/main-nav/main-nav.component.html"),
            styles: [__webpack_require__(/*! ./main-nav.component.css */ "./src/app/main-nav/main-nav.component.css")]
        })
    ], MainNavComponent);
    return MainNavComponent;
}());



/***/ }),

/***/ "./src/app/main/about-us/about-us.component.css":
/*!******************************************************!*\
  !*** ./src/app/main/about-us/about-us.component.css ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21haW4vYWJvdXQtdXMvYWJvdXQtdXMuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/main/about-us/about-us.component.ts":
/*!*****************************************************!*\
  !*** ./src/app/main/about-us/about-us.component.ts ***!
  \*****************************************************/
/*! exports provided: AboutUsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutUsComponent", function() { return AboutUsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var AboutUsComponent = /** @class */ (function () {
    function AboutUsComponent() {
    }
    AboutUsComponent.prototype.ngOnInit = function () {
    };
    AboutUsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-about-us',
            template: __webpack_require__(/*! raw-loader!./about-us.component.html */ "./node_modules/raw-loader/index.js!./src/app/main/about-us/about-us.component.html"),
            styles: [__webpack_require__(/*! ./about-us.component.css */ "./src/app/main/about-us/about-us.component.css")]
        })
    ], AboutUsComponent);
    return AboutUsComponent;
}());



/***/ }),

/***/ "./src/app/main/contac-form/contac-form.component.css":
/*!************************************************************!*\
  !*** ./src/app/main/contac-form/contac-form.component.css ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21haW4vY29udGFjLWZvcm0vY29udGFjLWZvcm0uY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/main/contac-form/contac-form.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/main/contac-form/contac-form.component.ts ***!
  \***********************************************************/
/*! exports provided: ContacFormComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContacFormComponent", function() { return ContacFormComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var ContacFormComponent = /** @class */ (function () {
    function ContacFormComponent() {
    }
    ContacFormComponent.prototype.ngOnInit = function () {
    };
    ContacFormComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-contac-form',
            template: __webpack_require__(/*! raw-loader!./contac-form.component.html */ "./node_modules/raw-loader/index.js!./src/app/main/contac-form/contac-form.component.html"),
            styles: [__webpack_require__(/*! ./contac-form.component.css */ "./src/app/main/contac-form/contac-form.component.css")]
        })
    ], ContacFormComponent);
    return ContacFormComponent;
}());



/***/ }),

/***/ "./src/app/main/main.component.css":
/*!*****************************************!*\
  !*** ./src/app/main/main.component.css ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21haW4vbWFpbi5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/main/main.component.ts":
/*!****************************************!*\
  !*** ./src/app/main/main.component.ts ***!
  \****************************************/
/*! exports provided: MainComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainComponent", function() { return MainComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var aos__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! aos */ "./node_modules/aos/dist/aos.js");
/* harmony import */ var aos__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(aos__WEBPACK_IMPORTED_MODULE_2__);



var MainComponent = /** @class */ (function () {
    function MainComponent() {
    }
    MainComponent.prototype.ngOnInit = function () {
        $('.animated .test-main-row').slick({
            dots: true,
            infinite: true,
            speed: 500,
            slidesToShow: 1,
            fade: true,
        });
        //
        aos__WEBPACK_IMPORTED_MODULE_2__["init"]({
            duration: 1200,
        });
    };
    MainComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-main',
            template: __webpack_require__(/*! raw-loader!./main.component.html */ "./node_modules/raw-loader/index.js!./src/app/main/main.component.html"),
            styles: [__webpack_require__(/*! ./main.component.css */ "./src/app/main/main.component.css")]
        })
    ], MainComponent);
    return MainComponent;
}());



/***/ }),

/***/ "./src/app/main/our-skills/our-skills.component.css":
/*!**********************************************************!*\
  !*** ./src/app/main/our-skills/our-skills.component.css ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21haW4vb3VyLXNraWxscy9vdXItc2tpbGxzLmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/main/our-skills/our-skills.component.ts":
/*!*********************************************************!*\
  !*** ./src/app/main/our-skills/our-skills.component.ts ***!
  \*********************************************************/
/*! exports provided: OurSkillsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OurSkillsComponent", function() { return OurSkillsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/animations */ "./node_modules/@angular/animations/fesm5/animations.js");
/* harmony import */ var ng_animate__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ng-animate */ "./node_modules/ng-animate/fesm5/ng-animate.js");




var OurSkillsComponent = /** @class */ (function () {
    function OurSkillsComponent() {
    }
    OurSkillsComponent.prototype.ngOnInit = function () {
    };
    OurSkillsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-our-skills',
            template: __webpack_require__(/*! raw-loader!./our-skills.component.html */ "./node_modules/raw-loader/index.js!./src/app/main/our-skills/our-skills.component.html"),
            animations: [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_2__["trigger"])('bounce', [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_2__["transition"])('* => *', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_2__["useAnimation"])(ng_animate__WEBPACK_IMPORTED_MODULE_3__["bounce"], {
                        // Set the duration to 5seconds and delay to 2seconds
                        params: { timing: 5, delay: 2 }
                    }))])
            ],
            styles: [__webpack_require__(/*! ./our-skills.component.css */ "./src/app/main/our-skills/our-skills.component.css")]
        })
    ], OurSkillsComponent);
    return OurSkillsComponent;
}());



/***/ }),

/***/ "./src/app/main/services/services-cards/services-cards.component.css":
/*!***************************************************************************!*\
  !*** ./src/app/main/services/services-cards/services-cards.component.css ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21haW4vc2VydmljZXMvc2VydmljZXMtY2FyZHMvc2VydmljZXMtY2FyZHMuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/main/services/services-cards/services-cards.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/main/services/services-cards/services-cards.component.ts ***!
  \**************************************************************************/
/*! exports provided: ServicesCardsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServicesCardsComponent", function() { return ServicesCardsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var ServicesCardsComponent = /** @class */ (function () {
    function ServicesCardsComponent() {
    }
    ServicesCardsComponent.prototype.ngOnInit = function () {
    };
    ServicesCardsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-services-cards',
            template: __webpack_require__(/*! raw-loader!./services-cards.component.html */ "./node_modules/raw-loader/index.js!./src/app/main/services/services-cards/services-cards.component.html"),
            styles: [__webpack_require__(/*! ./services-cards.component.css */ "./src/app/main/services/services-cards/services-cards.component.css")]
        })
    ], ServicesCardsComponent);
    return ServicesCardsComponent;
}());



/***/ }),

/***/ "./src/app/main/services/services.component.css":
/*!******************************************************!*\
  !*** ./src/app/main/services/services.component.css ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21haW4vc2VydmljZXMvc2VydmljZXMuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/main/services/services.component.ts":
/*!*****************************************************!*\
  !*** ./src/app/main/services/services.component.ts ***!
  \*****************************************************/
/*! exports provided: ServicesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServicesComponent", function() { return ServicesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var ServicesComponent = /** @class */ (function () {
    function ServicesComponent() {
    }
    ServicesComponent.prototype.ngOnInit = function () {
    };
    ServicesComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-services',
            template: __webpack_require__(/*! raw-loader!./services.component.html */ "./node_modules/raw-loader/index.js!./src/app/main/services/services.component.html"),
            styles: [__webpack_require__(/*! ./services.component.css */ "./src/app/main/services/services.component.css")]
        })
    ], ServicesComponent);
    return ServicesComponent;
}());



/***/ }),

/***/ "./src/app/main/testimonilas/testi-cards/testi-cards.component.css":
/*!*************************************************************************!*\
  !*** ./src/app/main/testimonilas/testi-cards/testi-cards.component.css ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21haW4vdGVzdGltb25pbGFzL3Rlc3RpLWNhcmRzL3Rlc3RpLWNhcmRzLmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/main/testimonilas/testi-cards/testi-cards.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/main/testimonilas/testi-cards/testi-cards.component.ts ***!
  \************************************************************************/
/*! exports provided: TestiCardsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TestiCardsComponent", function() { return TestiCardsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var TestiCardsComponent = /** @class */ (function () {
    function TestiCardsComponent() {
    }
    TestiCardsComponent.prototype.ngOnInit = function () {
    };
    TestiCardsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-testi-cards',
            template: __webpack_require__(/*! raw-loader!./testi-cards.component.html */ "./node_modules/raw-loader/index.js!./src/app/main/testimonilas/testi-cards/testi-cards.component.html"),
            styles: [__webpack_require__(/*! ./testi-cards.component.css */ "./src/app/main/testimonilas/testi-cards/testi-cards.component.css")]
        })
    ], TestiCardsComponent);
    return TestiCardsComponent;
}());



/***/ }),

/***/ "./src/app/main/testimonilas/testimonilas.component.css":
/*!**************************************************************!*\
  !*** ./src/app/main/testimonilas/testimonilas.component.css ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21haW4vdGVzdGltb25pbGFzL3Rlc3RpbW9uaWxhcy5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/main/testimonilas/testimonilas.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/main/testimonilas/testimonilas.component.ts ***!
  \*************************************************************/
/*! exports provided: TestimonilasComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TestimonilasComponent", function() { return TestimonilasComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var TestimonilasComponent = /** @class */ (function () {
    function TestimonilasComponent() {
    }
    TestimonilasComponent.prototype.ngOnInit = function () {
    };
    TestimonilasComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-testimonilas',
            template: __webpack_require__(/*! raw-loader!./testimonilas.component.html */ "./node_modules/raw-loader/index.js!./src/app/main/testimonilas/testimonilas.component.html"),
            styles: [__webpack_require__(/*! ./testimonilas.component.css */ "./src/app/main/testimonilas/testimonilas.component.css")]
        })
    ], TestimonilasComponent);
    return TestimonilasComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! hammerjs */ "./node_modules/hammerjs/hammer.js");
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(hammerjs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");





if (_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
}
//enableProdMode();
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\koina\Desktop\Angular\NgApp\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es5.js.map